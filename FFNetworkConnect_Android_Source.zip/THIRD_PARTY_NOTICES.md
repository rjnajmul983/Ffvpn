# Third-Party Notices & Open-Source License Compliance

FF Network Connect is licensed under **GPL-3.0-only** to maintain full license compatibility
with its upstream foundation, [WhiteDNS/WhiteVPN](https://github.com/WhiteDNS/WhiteVPN).

## Upstream & Third-Party Components

| Component | Repository / Source | License | Role in FF Network Connect |
|---|---|---|---|
| WhiteVPN | https://github.com/WhiteDNS/WhiteVPN | GPL-3.0-only | Reference architecture, lifecycle model (`CONTEXT.md`), and security audit mitigations (`SECURITY-AUDIT.md`) |
| WireGuard-Android Tunnel | https://git.zx2c4.com/wireguard-android (`com.wireguard.android:tunnel`) | Apache-2.0 | Official userspace WireGuard GoBackend & `VpnService` tunnel engine |
| WhiteDNS/mihomo (Optional CI) | https://github.com/WhiteDNS/mihomo | GPL-3.0 | Optional Mihomo proxy core when native core CI build is enabled |
| WhiteDNS/FlClash (Optional CI) | https://github.com/WhiteDNS/FlClash | GPL-3.0 | Optional Android JNI bridge for Mihomo core |
| AndroidX & Jetpack Compose | https://developer.android.com/jetpack | Apache-2.0 | UI framework (Material 3), Room, DataStore, Lifecycle, Navigation |
| Kotlin & Coroutines | https://github.com/JetBrains/kotlin | Apache-2.0 | Language runtime and structured concurrency |

## Removed Upstream Components
- **Firebase Analytics**: Deliberately removed (resolving WhiteVPN `SECURITY-AUDIT.md` Finding #15 regarding merged `AD_ID` and install-referrer permissions).
- **ByeByeDPI (`byedpi_bridge.cpp`)**: Deliberately excluded (resolving Finding #14 FD race and adhering to the no-DPI-circumvention policy).
- **Hardcoded Payload Keys**: Excluded (resolving Finding #1); all user-imported configs are encrypted locally using Android Keystore AES-256-GCM.
