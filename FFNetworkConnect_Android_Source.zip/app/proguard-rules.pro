# Keep WireGuard GoBackend JNI entry points
-keep class com.wireguard.android.backend.** { *; }
-keep class com.wireguard.config.** { *; }
-keep class com.ffnetwork.connect.vpn.MihomoNativeBridge { *; }
