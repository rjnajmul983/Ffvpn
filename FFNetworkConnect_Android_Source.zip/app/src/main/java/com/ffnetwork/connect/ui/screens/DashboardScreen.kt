package com.ffnetwork.connect.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffnetwork.connect.data.local.VpnProfileEntity
import com.ffnetwork.connect.diagnostics.DeviceNetworkInfo
import com.ffnetwork.connect.diagnostics.DiagnosticProbeResult
import com.ffnetwork.connect.ui.DiagnosticsUiState
import com.ffnetwork.connect.ui.theme.*
import com.ffnetwork.connect.vpn.LifecyclePhase
import com.ffnetwork.connect.vpn.VpnRuntimeState
import kotlinx.coroutines.delay

@Composable
fun DashboardScreen(
    vpnState: VpnRuntimeState,
    networkInfo: DeviceNetworkInfo,
    selectedProfile: VpnProfileEntity?,
    diagnosticsUi: DiagnosticsUiState,
    onToggleVpn: () -> Unit,
    onRunDiagnostics: () -> Unit,
    onNavigate: (String) -> Unit
) {
    var elapsedSec by remember(vpnState.connectedSinceEpochMs, vpnState.phase) { mutableLongStateOf(0L) }
    LaunchedEffect(vpnState.connectedSinceEpochMs, vpnState.phase) {
        if (vpnState.phase == LifecyclePhase.ACTIVE && vpnState.connectedSinceEpochMs != null) {
            while (true) {
                elapsedSec = ((System.currentTimeMillis() - vpnState.connectedSinceEpochMs) / 1000L).coerceAtLeast(0L)
                delay(1000L)
            }
        } else {
            elapsedSec = 0L
        }
    }

    val latestProbe: DiagnosticProbeResult? =
        if (vpnState.phase == LifecyclePhase.ACTIVE) diagnosticsUi.lastVpnResult ?: diagnosticsUi.lastDirectResult
        else diagnosticsUi.lastDirectResult

    val statusColor = when (vpnState.phase) {
        LifecyclePhase.ACTIVE -> NeonGreen
        LifecyclePhase.ESTABLISHING, LifecyclePhase.RELEASING -> AlertAmber
        LifecyclePhase.ERROR -> AlertRed
        LifecyclePhase.INACTIVE -> ElectricBlue
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Brand Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "FF NETWORK CONNECT",
                    color = ElectricBlue,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "Hybrid VPN & Gaming Diagnostics",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = { onNavigate("history") }) {
                    Icon(Icons.Default.History, contentDescription = "History", tint = TextPrimary)
                }
                IconButton(onClick = { onNavigate("settings") }) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = TextPrimary)
                }
            }
        }

        // Main Connection Orb Card
        Card(
            colors = CardDefaults.cardColors(containerColor = NavySurface),
            border = BorderStroke(1.dp, statusColor.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(112.dp)
                        .clip(CircleShape)
                        .background(statusColor.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Button(
                        onClick = onToggleVpn,
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = statusColor),
                        modifier = Modifier.size(88.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = "Connect or Disconnect VPN",
                            tint = NavyBackground,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }

                Text(
                    text = when (vpnState.phase) {
                        LifecyclePhase.ACTIVE -> "VPN CONNECTED"
                        LifecyclePhase.ESTABLISHING -> "ESTABLISHING TUNNEL..."
                        LifecyclePhase.RELEASING -> "DISCONNECTING..."
                        LifecyclePhase.ERROR -> "CONNECTION ERROR"
                        LifecyclePhase.INACTIVE -> "DIRECT MODE (VPN OFF)"
                    },
                    color = statusColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )

                Text(
                    text = if (selectedProfile != null) {
                        "${selectedProfile.name} • ${selectedProfile.protocol} (${selectedProfile.regionLabel})"
                    } else {
                        "No VPN profile imported — Diagnostics work without VPN"
                    },
                    color = TextSecondary,
                    fontSize = 13.sp
                )

                if (vpnState.phase == LifecyclePhase.ACTIVE) {
                    Text(
                        text = "Duration: ${formatDuration(elapsedSec)}  |  ↓ ${formatBytes(vpnState.rxBytes)}  ↑ ${formatBytes(vpnState.txBytes)}",
                        color = NeonGreen,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                vpnState.errorMessage?.let { err ->
                    Text(
                        text = err,
                        color = AlertRed,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // SIM & Active Network Card
        Card(
            colors = CardDefaults.cardColors(containerColor = NavySurface),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("NETWORK & CARRIER", color = ElectricBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricItem("SIM Operator", networkInfo.normalizedBangladeshCarrier, Modifier.weight(1f))
                    MetricItem("Network Type", networkInfo.networkType, Modifier.weight(1f))
                }
            }
        }

        // Measured Telemetry Card
        Card(
            colors = CardDefaults.cardColors(containerColor = NavySurface),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("LIVE DIAGNOSTICS (GENERAL INTERNET)", color = ElectricBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    TextButton(onClick = onRunDiagnostics, enabled = !diagnosticsUi.isRunning) {
                        Text(if (diagnosticsUi.isRunning) "Testing..." else "Measure Now", color = NeonGreen)
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricItem("Avg RTT", latestProbe?.takeIf { it.avgRttMs >= 0 }?.let { "${it.avgRttMs} ms" } ?: "--", Modifier.weight(1f))
                    MetricItem("Jitter", latestProbe?.let { "${it.jitterMs} ms" } ?: "--", Modifier.weight(1f))
                    MetricItem("Packet Loss", latestProbe?.let { "${"%.1f".format(it.packetLossPercent)}%" } ?: "--", Modifier.weight(1f))
                }
                Text(diagnosticsUi.statusMessage, color = TextSecondary, fontSize = 12.sp)
            }
        }

        // Quick Navigation Row for Secondary Screens
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                onClick = { onNavigate("privacy") },
                modifier = Modifier.weight(1f),
                border = BorderStroke(1.dp, NavySurfaceVariant)
            ) {
                Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Privacy", fontSize = 12.sp)
            }
            OutlinedButton(
                onClick = { onNavigate("about") },
                modifier = Modifier.weight(1f),
                border = BorderStroke(1.dp, NavySurfaceVariant)
            ) {
                Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("About & GPL", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun MetricItem(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Text(label, color = TextSecondary, fontSize = 11.sp)
        Text(value, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun formatDuration(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return "%02d:%02d:%02d".format(h, m, s)
}

private fun formatBytes(bytes: Long): String {
    return when {
        bytes >= 1_073_741_824 -> "%.2f GB".format(bytes / 1_073_741_824.0)
        bytes >= 1_048_576 -> "%.2f MB".format(bytes / 1_048_576.0)
        bytes >= 1024 -> "%.1f KB".format(bytes / 1024.0)
        else -> "$bytes B"
    }
}
