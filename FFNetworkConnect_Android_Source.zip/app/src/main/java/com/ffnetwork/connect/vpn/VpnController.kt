package com.ffnetwork.connect.vpn

import android.content.Context
import android.content.Intent
import android.net.TrafficStats
import android.net.VpnService
import android.os.Build
import com.ffnetwork.connect.data.local.AppDatabase
import com.ffnetwork.connect.data.local.ConnectionSessionEntity
import com.ffnetwork.connect.data.local.UserSettings
import com.ffnetwork.connect.data.local.VpnProfileEntity
import com.ffnetwork.connect.security.SecureVault
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.StringReader

/**
 * Real Android VPN Controller backed by official WireGuard GoBackend (Android VpnService API).
 * Guarantees honest state transitions — never fabricates a connected state if tunnel establishment fails.
 */
class VpnController private constructor(private val appContext: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val backend: GoBackend by lazy { GoBackend(appContext) }
    private val vault = SecureVault()
    private val db = AppDatabase.getInstance(appContext)

    private val _state = MutableStateFlow(
        VpnRuntimeState(mihomoNativeAvailable = MihomoNativeBridge.isAvailable)
    )
    val state: StateFlow<VpnRuntimeState> = _state.asStateFlow()

    private var activeTunnel: Tunnel? = null
    private var activeSessionRowId: Long? = null
    private var statsJob: Job? = null
    private var baselineRxBytes: Long = 0L
    private var baselineTxBytes: Long = 0L

    fun prepareVpnPermission(): Intent? = VpnService.prepare(appContext)

    suspend fun connect(profile: VpnProfileEntity, settings: UserSettings): Result<Unit> =
        withContext(Dispatchers.IO) {
            if (profile.protocol.equals("Mihomo", ignoreCase = true) && !MihomoNativeBridge.isAvailable) {
                val msg = "Mihomo native core (libclash.so) is not bundled in this build. Use a WireGuard (.conf) profile or enable the native Mihomo CI job."
                _state.update { it.copy(phase = LifecyclePhase.ERROR, errorMessage = msg) }
                return@withContext Result.failure(IllegalStateException(msg))
            }

            if (VpnService.prepare(appContext) != null) {
                val msg = "Android VPN permission has not been granted yet."
                _state.update { it.copy(phase = LifecyclePhase.ERROR, errorMessage = msg) }
                return@withContext Result.failure(SecurityException(msg))
            }

            _state.update {
                it.copy(
                    phase = LifecyclePhase.ESTABLISHING,
                    activeProfileId = profile.id,
                    activeProfileName = profile.name,
                    activeProviderName = profile.providerId,
                    protocol = profile.protocol,
                    errorMessage = null
                )
            }

            try {
                val decryptedConfig = vault.decrypt(profile.encryptedConfig)
                val finalConfigText = applyUserSettingsToWireGuard(decryptedConfig, settings)
                val wgConfig = Config.parse(BufferedReader(StringReader(finalConfigText)))

                // Cleanly release any prior tunnel
                activeTunnel?.let { existing ->
                    runCatching { backend.setState(existing, Tunnel.State.DOWN, null) }
                }

                val tunnel = object : Tunnel {
                    override fun getName(): String = "ffnc_${profile.id}"
                    override fun onStateChange(newState: Tunnel.State) {
                        if (newState == Tunnel.State.DOWN && _state.value.phase == LifecyclePhase.ACTIVE) {
                            scope.launch { finalizeDisconnect("Tunnel revoked or closed by system") }
                        }
                    }
                }

                val resultingState = backend.setState(tunnel, Tunnel.State.UP, wgConfig)
                if (resultingState != Tunnel.State.UP) {
                    throw IllegalStateException("WireGuard GoBackend did not reach UP state (state=$resultingState)")
                }

                activeTunnel = tunnel
                val now = System.currentTimeMillis()
                baselineRxBytes = TrafficStats.getTotalRxBytes().coerceAtLeast(0L)
                baselineTxBytes = TrafficStats.getTotalTxBytes().coerceAtLeast(0L)

                activeSessionRowId = db.connectionSessionDao().insert(
                    ConnectionSessionEntity(
                        profileName = profile.name,
                        providerName = profile.providerId,
                        protocol = profile.protocol,
                        startedAtEpochMs = now
                    )
                )

                startMonitorService(profile.name)
                startTrafficPolling()

                _state.update {
                    it.copy(
                        phase = LifecyclePhase.ACTIVE,
                        connectedSinceEpochMs = now,
                        rxBytes = 0L,
                        txBytes = 0L,
                        errorMessage = null
                    )
                }
                Result.success(Unit)
            } catch (e: Exception) {
                stopMonitorService()
                _state.update {
                    it.copy(
                        phase = LifecyclePhase.ERROR,
                        connectedSinceEpochMs = null,
                        errorMessage = e.message ?: "Failed to establish VPN tunnel"
                    )
                }
                Result.failure(e)
            }
        }

    fun disconnectAsync(reason: String = "User disconnected") {
        scope.launch { disconnect(reason) }
    }

    suspend fun disconnect(reason: String = "User disconnected") = withContext(Dispatchers.IO) {
        _state.update { it.copy(phase = LifecyclePhase.RELEASING) }
        try {
            activeTunnel?.let { tunnel ->
                backend.setState(tunnel, Tunnel.State.DOWN, null)
            }
        } catch (_: Exception) {
            // Ensure state release proceeds even if backend already tore down
        } finally {
            finalizeDisconnect(reason)
        }
    }

    private suspend fun finalizeDisconnect(reason: String) {
        statsJob?.cancel()
        statsJob = null
        activeTunnel = null
        stopMonitorService()

        val current = _state.value
        activeSessionRowId?.let { rowId ->
            runCatching {
                db.connectionSessionDao().closeSession(
                    id = rowId,
                    endedAt = System.currentTimeMillis(),
                    rx = current.rxBytes,
                    tx = current.txBytes,
                    reason = reason
                )
            }
        }
        activeSessionRowId = null

        _state.update {
            it.copy(
                phase = LifecyclePhase.INACTIVE,
                connectedSinceEpochMs = null,
                rxBytes = 0L,
                txBytes = 0L,
                errorMessage = null
            )
        }
    }

    private fun startTrafficPolling() {
        statsJob?.cancel()
        statsJob = scope.launch {
            while (isActive) {
                delay(1500L)
                val tunnel = activeTunnel ?: break
                val stats = runCatching { backend.getStatistics(tunnel) }.getOrNull()
                val rx = stats?.totalRx()
                    ?: (TrafficStats.getTotalRxBytes() - baselineRxBytes).coerceAtLeast(0L)
                val tx = stats?.totalTx()
                    ?: (TrafficStats.getTotalTxBytes() - baselineTxBytes).coerceAtLeast(0L)
                _state.update { it.copy(rxBytes = rx, txBytes = tx) }
            }
        }
    }

    private fun applyUserSettingsToWireGuard(raw: String, settings: UserSettings): String {
        val lines = raw.lines().toMutableList()
        val interfaceIdx = lines.indexOfFirst { it.trim().equals("[Interface]", ignoreCase = true) }
        if (interfaceIdx == -1) return raw

        // Inject preferred DNS if user selected a custom one and config doesn't override
        val hasDns = lines.any { it.trim().startsWith("DNS", ignoreCase = true) }
        if (!hasDns && settings.preferredDns.isNotBlank()) {
            lines.add(interfaceIdx + 1, "DNS = ${settings.preferredDns}")
        }

        // Apply per-app split tunneling if configured
        if (settings.splitTunnelPackages.isNotEmpty()) {
            val joined = settings.splitTunnelPackages.joinToString(", ")
            when (settings.splitTunnelMode) {
                "EXCLUDE_SELECTED" -> lines.add(interfaceIdx + 1, "ExcludedApplications = $joined")
                "ONLY_SELECTED" -> lines.add(interfaceIdx + 1, "IncludedApplications = $joined")
            }
        }
        return lines.joinToString("\n")
    }

    private fun startMonitorService(profileName: String) {
        val intent = Intent(appContext, FFMonitorService::class.java).apply {
            action = FFMonitorService.ACTION_START
            putExtra(FFMonitorService.EXTRA_PROFILE_NAME, profileName)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            appContext.startForegroundService(intent)
        } else {
            appContext.startService(intent)
        }
    }

    private fun stopMonitorService() {
        val intent = Intent(appContext, FFMonitorService::class.java).apply {
            action = FFMonitorService.ACTION_STOP
        }
        appContext.stopService(intent)
    }

    companion object {
        @Volatile
        private var INSTANCE: VpnController? = null

        fun getInstance(context: Context): VpnController {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: VpnController(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
