package com.ffnetwork.connect.ui

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ffnetwork.connect.data.local.AppDatabase
import com.ffnetwork.connect.data.local.ConnectionSessionEntity
import com.ffnetwork.connect.data.local.DiagnosticRecordEntity
import com.ffnetwork.connect.data.local.UserPreferencesRepository
import com.ffnetwork.connect.data.local.UserSettings
import com.ffnetwork.connect.data.local.VpnProfileEntity
import com.ffnetwork.connect.diagnostics.DeviceNetworkInfo
import com.ffnetwork.connect.diagnostics.DiagnosticProbeResult
import com.ffnetwork.connect.diagnostics.NetworkDiagnosticsEngine
import com.ffnetwork.connect.diagnostics.SimAndNetworkDetector
import com.ffnetwork.connect.provider.AuthorizedProviderCatalog
import com.ffnetwork.connect.provider.FreeVpnProvider
import com.ffnetwork.connect.provider.WireGuardConfigParser
import com.ffnetwork.connect.security.ConfigSecurityValidator
import com.ffnetwork.connect.security.SecureVault
import com.ffnetwork.connect.vpn.LifecyclePhase
import com.ffnetwork.connect.vpn.VpnController
import com.ffnetwork.connect.vpn.VpnRuntimeState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DiagnosticsUiState(
    val isRunning: Boolean = false,
    val lastDirectResult: DiagnosticProbeResult? = null,
    val lastVpnResult: DiagnosticProbeResult? = null,
    val statusMessage: String = "Ready — works independently without any VPN server."
)

data class ImportStatus(
    val message: String? = null,
    val isError: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val prefs = UserPreferencesRepository(application)
    private val vpnController = VpnController.getInstance(application)
    private val detector = SimAndNetworkDetector(application)
    private val vault = SecureVault()

    val providers: List<FreeVpnProvider> = AuthorizedProviderCatalog.providers

    val vpnState: StateFlow<VpnRuntimeState> = vpnController.state

    val networkInfo: StateFlow<DeviceNetworkInfo> = detector.observeNetworkSwitches()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), detector.snapshot())

    val settings: StateFlow<UserSettings> = prefs.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    val profiles: StateFlow<List<VpnProfileEntity>> = db.vpnProfileDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val diagnosticHistory: StateFlow<List<DiagnosticRecordEntity>> = db.diagnosticRecordDao().observeRecent()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sessionHistory: StateFlow<List<ConnectionSessionEntity>> = db.connectionSessionDao().observeRecent()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _diagnosticsUi = MutableStateFlow(DiagnosticsUiState())
    val diagnosticsUi: StateFlow<DiagnosticsUiState> = _diagnosticsUi.asStateFlow()

    private val _importStatus = MutableStateFlow(ImportStatus())
    val importStatus: StateFlow<ImportStatus> = _importStatus.asStateFlow()

    fun prepareVpnPermission(): Intent? = vpnController.prepareVpnPermission()

    fun toggleConnection() {
        val current = vpnState.value
        if (current.phase == LifecyclePhase.ACTIVE || current.phase == LifecyclePhase.ESTABLISHING) {
            vpnController.disconnectAsync("User disconnected")
            return
        }
        viewModelScope.launch {
            val selectedId = settings.value.selectedProfileId
            val targetProfile = profiles.value.firstOrNull { it.id == selectedId }
                ?: profiles.value.firstOrNull()
            if (targetProfile == null) {
                _importStatus.value = ImportStatus(
                    message = "No VPN profile imported yet. Import a WireGuard .conf (e.g., Proton VPN Free) on the Servers tab.",
                    isError = true
                )
                return@launch
            }
            vpnController.connect(targetProfile, settings.value)
        }
    }

    fun selectProfile(profileId: Long) {
        viewModelScope.launch {
            prefs.setSelectedProfileId(profileId)
        }
    }

    fun deleteProfile(profileId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            if (vpnState.value.activeProfileId == profileId && vpnState.value.phase == LifecyclePhase.ACTIVE) {
                vpnController.disconnect("Profile deleted")
            }
            db.vpnProfileDao().deleteById(profileId)
        }
    }

    fun importWireGuardConfig(
        name: String,
        providerId: String,
        regionLabel: String,
        rawConfig: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val parsed = WireGuardConfigParser.parse(rawConfig)
            if (parsed.isFailure) {
                _importStatus.value = ImportStatus(
                    message = parsed.exceptionOrNull()?.message ?: "Invalid WireGuard configuration",
                    isError = true
                )
                return@launch
            }
            val wg = parsed.getOrThrow()
            val encrypted = runCatching { vault.encrypt(wg.normalizedConfigText) }.getOrElse {
                _importStatus.value = ImportStatus("Keystore encryption failed: ${it.message}", isError = true)
                return@launch
            }
            val entity = VpnProfileEntity(
                name = name.ifBlank { "WireGuard (${wg.endpointHost})" },
                providerId = providerId,
                protocol = "WireGuard",
                endpointHost = wg.endpointHost,
                endpointPort = wg.endpointPort,
                regionLabel = regionLabel.ifBlank { "Custom" },
                encryptedConfig = encrypted
            )
            val newId = db.vpnProfileDao().insert(entity)
            prefs.setSelectedProfileId(newId)
            _importStatus.value = ImportStatus(
                message = "Imported & encrypted '${entity.name}' (${wg.endpointHost}:${wg.endpointPort})",
                isError = false
            )
        }
    }

    fun importMihomoYamlConfig(name: String, rawYaml: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val check = ConfigSecurityValidator.validateMihomoYaml(rawYaml)
            if (!check.isValid) {
                _importStatus.value = ImportStatus(
                    message = check.errors.joinToString(" "),
                    isError = true
                )
                return@launch
            }
            val encrypted = vault.encrypt(rawYaml)
            val entity = VpnProfileEntity(
                name = name.ifBlank { "Mihomo Profile" },
                providerId = "custom_byoc",
                protocol = "Mihomo",
                endpointHost = "mihomo-yaml",
                endpointPort = 443,
                regionLabel = "Mihomo",
                encryptedConfig = encrypted
            )
            val newId = db.vpnProfileDao().insert(entity)
            prefs.setSelectedProfileId(newId)
            _importStatus.value = ImportStatus(
                message = "Validated & encrypted Mihomo YAML '${entity.name}'.",
                isError = false
            )
        }
    }

    fun testProfileLatency(profile: VpnProfileEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            if (profile.endpointHost == "mihomo-yaml") return@launch
            val rtt = NetworkDiagnosticsEngine.measureEndpointTcpRtt(profile.endpointHost, profile.endpointPort)
            db.vpnProfileDao().updateRtt(profile.id, rtt)
        }
    }

    fun runNetworkDiagnostics() {
        if (_diagnosticsUi.value.isRunning) return
        viewModelScope.launch {
            val isVpnActive = vpnState.value.phase == LifecyclePhase.ACTIVE || networkInfo.value.isVpnTransportActive
            val modeLabel = if (isVpnActive) "VPN" else "DIRECT"
            _diagnosticsUi.update {
                it.copy(isRunning = true, statusMessage = "Measuring DNS, RTT, Jitter & Packet Loss ($modeLabel)...")
            }

            val dnsHost = when (settings.value.preferredDns) {
                "8.8.8.8" -> "8.8.8.8"
                "9.9.9.9" -> "9.9.9.9"
                else -> "1.1.1.1"
            }
            val result = NetworkDiagnosticsEngine.runFullProbe(host = dnsHost, port = 443)
            val net = detector.snapshot()

            db.diagnosticRecordDao().insert(
                DiagnosticRecordEntity(
                    connectionMode = modeLabel,
                    simOperator = net.normalizedBangladeshCarrier,
                    networkType = net.networkType,
                    dnsLatencyMs = result.dnsLatencyMs,
                    avgRttMs = result.avgRttMs,
                    jitterMs = result.jitterMs,
                    packetLossPercent = result.packetLossPercent,
                    stabilityScore = result.stabilityScore,
                    internetReachable = result.internetReachable,
                    probeEndpoint = result.probeEndpoint
                )
            )

            _diagnosticsUi.update {
                it.copy(
                    isRunning = false,
                    lastDirectResult = if (modeLabel == "DIRECT") result else it.lastDirectResult,
                    lastVpnResult = if (modeLabel == "VPN") result else it.lastVpnResult,
                    statusMessage = if (result.internetReachable) {
                        "$modeLabel probe complete: ${result.avgRttMs} ms RTT, ${result.jitterMs} ms jitter, ${result.packetLossPercent}% loss."
                    } else {
                        "$modeLabel probe failed: endpoint unreachable."
                    }
                )
            }
        }
    }

    fun updatePreferredDns(dns: String) = viewModelScope.launch { prefs.setPreferredDns(dns) }
    fun updateIpv6(enabled: Boolean) = viewModelScope.launch { prefs.setIpv6Enabled(enabled) }
    fun updateKillSwitchReminder(enabled: Boolean) = viewModelScope.launch { prefs.setKillSwitchReminder(enabled) }
    fun updateSplitTunnel(mode: String, packages: Set<String>) = viewModelScope.launch {
        prefs.setSplitTunnel(mode, packages)
    }

    fun clearDiagnosticsHistory() = viewModelScope.launch(Dispatchers.IO) {
        db.diagnosticRecordDao().clearAll()
    }

    fun clearSessionHistory() = viewModelScope.launch(Dispatchers.IO) {
        db.connectionSessionDao().clearAll()
    }

    fun wipeAllLocalData() = viewModelScope.launch(Dispatchers.IO) {
        vpnController.disconnect("All local data cleared")
        db.vpnProfileDao().deleteAll()
        db.diagnosticRecordDao().clearAll()
        db.connectionSessionDao().clearAll()
        prefs.clearAll()
        vault.wipeKey()
        _importStatus.value = ImportStatus("All imported configs, vault keys, and history deleted.", isError = false)
    }

    fun clearImportBanner() {
        _importStatus.value = ImportStatus()
    }
}
