package com.ffnetwork.connect.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffnetwork.connect.data.local.VpnProfileEntity
import com.ffnetwork.connect.provider.FreeVpnProvider
import com.ffnetwork.connect.ui.ImportStatus
import com.ffnetwork.connect.ui.theme.*

@Composable
fun ProvidersScreen(
    providers: List<FreeVpnProvider>,
    onGoToImport: () -> Unit
) {
    val context = LocalContext.current
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("AUTHORIZED FREE VPN PROVIDERS", color = ElectricBlue, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Only verified official providers are listed. Free plans can change terms anytime; no scraped or unauthorized servers are included.",
                color = TextSecondary,
                fontSize = 12.sp
            )
        }

        items(providers, key = { it.id }) { provider ->
            val badgeColor = if (provider.manualConfigImportSupportedOnFree) NeonGreen else AlertAmber
            Card(
                colors = CardDefaults.cardColors(containerColor = NavySurface),
                border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(provider.name, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (provider.manualConfigImportSupportedOnFree) "IMPORTABLE FREE" else "OFFICIAL APP ONLY",
                            color = badgeColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text("Protocols: ${provider.supportedProtocols.joinToString(", ")}", color = ElectricBlue, fontSize = 12.sp)
                    Text("Setup: ${provider.configurationMethod}", color = TextPrimary, fontSize = 12.sp)
                    Text("Servers: ${provider.serverAvailabilitySummary}", color = TextSecondary, fontSize = 12.sp)
                    Text("Limits: ${provider.usageRestrictions}", color = TextSecondary, fontSize = 12.sp)
                    Text("Last verified: ${provider.lastVerifiedDate}", color = TextSecondary, fontSize = 11.sp)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                        OutlinedButton(
                            onClick = {
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(provider.officialWebsite)))
                                }
                            }
                        ) {
                            Text("Official Site", fontSize = 12.sp)
                        }
                        if (provider.manualConfigImportSupportedOnFree) {
                            Button(onClick = onGoToImport) {
                                Text("Import Config", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ServersScreen(
    profiles: List<VpnProfileEntity>,
    selectedProfileId: Long,
    importStatus: ImportStatus,
    onSelectProfile: (Long) -> Unit,
    onTestProfile: (VpnProfileEntity) -> Unit,
    onDeleteProfile: (Long) -> Unit,
    onImportWireGuard: (name: String, providerId: String, region: String, rawConf: String) -> Unit,
    onImportMihomo: (name: String, rawYaml: String) -> Unit,
    onDismissBanner: () -> Unit
) {
    var showImportDialog by remember { mutableStateOf(false) }
    var importMode by remember { mutableStateOf("WireGuard") }
    var profileName by remember { mutableStateOf("") }
    var regionLabel by remember { mutableStateOf("Proton Free") }
    var rawConfigText by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("SERVERS & CONFIGS", color = ElectricBlue, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Button(onClick = { showImportDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Import", fontSize = 12.sp)
            }
        }

        importStatus.message?.let { msg ->
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (importStatus.isError) AlertRed.copy(alpha = 0.2f) else NeonGreen.copy(alpha = 0.15f)
                )
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(msg, color = TextPrimary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = onDismissBanner) {
                        Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = TextPrimary)
                    }
                }
            }
        }

        if (profiles.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = NavySurface), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("No VPN Profiles Imported", color = TextPrimary, fontWeight = FontWeight.Bold)
                    Text(
                        "Tap 'Import' above to paste an official Proton VPN Free WireGuard (.conf) file or an authorized Mihomo YAML config. All private keys are encrypted with Android Keystore AES-256-GCM.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(profiles, key = { it.id }) { profile ->
                    val isSelected = profile.id == selectedProfileId
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NavySurface),
                        border = BorderStroke(1.dp, if (isSelected) NeonGreen else NavySurfaceVariant),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(profile.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text(
                                        "${profile.protocol} • ${profile.endpointHost}:${profile.endpointPort} • ${profile.regionLabel}",
                                        color = TextSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                                Text(
                                    text = profile.lastMeasuredRttMs?.let { "$it ms" } ?: "Untested",
                                    color = if (profile.lastMeasuredRttMs != null) NeonGreen else TextSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { onSelectProfile(profile.id) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSelected) NeonGreen else ElectricBlue
                                    )
                                ) {
                                    Text(if (isSelected) "Selected" else "Select", color = NavyBackground, fontSize = 12.sp)
                                }
                                OutlinedButton(onClick = { onTestProfile(profile) }) {
                                    Text("Ping Endpoint", fontSize = 12.sp)
                                }
                                IconButton(onClick = { onDeleteProfile(profile.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AlertRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            containerColor = NavySurface,
            title = { Text("Import Authorized Config", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = importMode == "WireGuard",
                            onClick = { importMode = "WireGuard" },
                            label = { Text("WireGuard .conf") }
                        )
                        FilterChip(
                            selected = importMode == "Mihomo",
                            onClick = { importMode = "Mihomo" },
                            label = { Text("Mihomo YAML") }
                        )
                    }
                    OutlinedTextField(
                        value = profileName,
                        onValueChange = { profileName = it },
                        label = { Text("Profile Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (importMode == "WireGuard") {
                        OutlinedTextField(
                            value = regionLabel,
                            onValueChange = { regionLabel = it },
                            label = { Text("Provider / Region") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    OutlinedTextField(
                        value = rawConfigText,
                        onValueChange = { rawConfigText = it },
                        label = { Text(if (importMode == "WireGuard") "Paste [Interface] / [Peer] .conf" else "Paste Mihomo YAML") },
                        minLines = 5,
                        maxLines = 8,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (importMode == "WireGuard") {
                        onImportWireGuard(profileName, "proton_vpn_free", regionLabel, rawConfigText)
                    } else {
                        onImportMihomo(profileName, rawConfigText)
                    }
                    rawConfigText = ""
                    profileName = ""
                    showImportDialog = false
                }) {
                    Text("Validate & Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) { Text("Cancel") }
            }
        )
    }
}
