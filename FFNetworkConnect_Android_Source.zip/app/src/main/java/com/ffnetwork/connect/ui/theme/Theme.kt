package com.ffnetwork.connect.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NavyBackground = Color(0xFF0A0E1A)
val NavySurface = Color(0xFF12192B)
val NavySurfaceVariant = Color(0xFF1B2540)
val ElectricBlue = Color(0xFF00A8FF)
val NeonGreen = Color(0xFF00F5A0)
val AlertAmber = Color(0xFFFFB703)
val AlertRed = Color(0xFFFF4D6D)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)

private val GamingDarkScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = Color(0xFF041320),
    secondary = NeonGreen,
    onSecondary = Color(0xFF031F14),
    background = NavyBackground,
    onBackground = TextPrimary,
    surface = NavySurface,
    onSurface = TextPrimary,
    surfaceVariant = NavySurfaceVariant,
    onSurfaceVariant = TextSecondary,
    error = AlertRed,
    onError = Color.White
)

@Composable
fun FFNetworkConnectTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = GamingDarkScheme,
        content = content
    )
}
