package com.ffnetwork.connect

import android.app.Application

class FFNetworkApp : Application()
