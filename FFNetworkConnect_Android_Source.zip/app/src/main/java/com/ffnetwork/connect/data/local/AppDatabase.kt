package com.ffnetwork.connect.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        VpnProfileEntity::class,
        DiagnosticRecordEntity::class,
        ConnectionSessionEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun vpnProfileDao(): VpnProfileDao
    abstract fun diagnosticRecordDao(): DiagnosticRecordDao
    abstract fun connectionSessionDao(): ConnectionSessionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ff_network_connect.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
