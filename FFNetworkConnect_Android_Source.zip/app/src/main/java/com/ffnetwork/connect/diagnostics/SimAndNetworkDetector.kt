package com.ffnetwork.connect.diagnostics

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

data class DeviceNetworkInfo(
    val simOperatorName: String,
    val normalizedBangladeshCarrier: String,
    val networkType: String,
    val isVpnTransportActive: Boolean,
    val isValidatedInternet: Boolean
)

/**
 * Detects Bangladeshi SIM operators (Grameenphone, Robi, Airtel, Banglalink, Teletalk)
 * and active transport type without modifying carrier/APN settings and while respecting Android permissions.
 */
class SimAndNetworkDetector(private val context: Context) {

    fun snapshot(): DeviceNetworkInfo {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = cm.activeNetwork
        val caps = activeNetwork?.let { cm.getNetworkCapabilities(it) }

        val isVpn = caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        val isValidated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true

        val rawCarrier = readSimOperatorName()
        val normalizedCarrier = normalizeBangladeshOperator(rawCarrier)
        val networkType = detectNetworkType(caps)

        return DeviceNetworkInfo(
            simOperatorName = rawCarrier,
            normalizedBangladeshCarrier = normalizedCarrier,
            networkType = networkType,
            isVpnTransportActive = isVpn,
            isValidatedInternet = isValidated
        )
    }

    fun observeNetworkSwitches(): Flow<DeviceNetworkInfo> = callbackFlow {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        trySend(snapshot())

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                trySend(snapshot())
            }
            override fun onLost(network: Network) {
                trySend(snapshot())
            }
            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                trySend(snapshot())
            }
        }

        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        runCatching { cm.registerNetworkCallback(request, callback) }

        awaitClose {
            runCatching { cm.unregisterNetworkCallback(callback) }
        }
    }

    private fun readSimOperatorName(): String {
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            ?: return "Unavailable"
        val name = runCatching {
            tm.simOperatorName?.takeIf { it.isNotBlank() }
                ?: tm.networkOperatorName?.takeIf { it.isNotBlank() }
        }.getOrNull()
        return name ?: "Unavailable (No SIM or restricted)"
    }

    private fun detectNetworkType(caps: NetworkCapabilities?): String {
        if (caps == null) return "Offline"
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "Wi-Fi"
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "Ethernet"
        if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
            return if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) "VPN Active" else "Unknown"
        }

        val hasPhonePerm = ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPhonePerm) return "Mobile Data (Grant Phone permission for 4G/5G detail)"

        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            ?: return "Mobile Data"

        val type = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) tm.dataNetworkType else TelephonyManager.NETWORK_TYPE_UNKNOWN
        }.getOrDefault(TelephonyManager.NETWORK_TYPE_UNKNOWN)

        return when (type) {
            TelephonyManager.NETWORK_TYPE_NR -> "5G NR"
            TelephonyManager.NETWORK_TYPE_LTE -> "4G LTE"
            TelephonyManager.NETWORK_TYPE_HSPAP,
            TelephonyManager.NETWORK_TYPE_HSPA,
            TelephonyManager.NETWORK_TYPE_HSDPA,
            TelephonyManager.NETWORK_TYPE_HSUPA,
            TelephonyManager.NETWORK_TYPE_UMTS -> "3G HSPA/UMTS"
            TelephonyManager.NETWORK_TYPE_EDGE,
            TelephonyManager.NETWORK_TYPE_GPRS -> "2G EDGE/GPRS"
            else -> "Mobile Data"
        }
    }

    companion object {
        fun normalizeBangladeshOperator(rawName: String): String {
            val lower = rawName.lowercase()
            return when {
                lower.contains("grameen") || lower == "gp" || lower.contains("47001") -> "Grameenphone"
                lower.contains("robi") || lower.contains("47002") -> "Robi"
                lower.contains("airtel") || lower.contains("47007") -> "Airtel"
                lower.contains("banglalink") || lower.contains("bl") || lower.contains("47003") -> "Banglalink"
                lower.contains("teletalk") || lower.contains("47004") -> "Teletalk"
                rawName.startsWith("Unavailable") -> "Carrier Unavailable"
                else -> rawName
            }
        }
    }
}
