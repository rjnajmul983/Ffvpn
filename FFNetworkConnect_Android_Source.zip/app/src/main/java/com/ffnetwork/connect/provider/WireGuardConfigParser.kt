package com.ffnetwork.connect.provider

data class ParsedWireGuardConfig(
    val privateKey: String,
    val address: String,
    val dns: String?,
    val mtu: Int?,
    val publicKey: String,
    val presharedKey: String?,
    val endpointHost: String,
    val endpointPort: Int,
    val allowedIps: String,
    val persistentKeepalive: Int?,
    val normalizedConfigText: String
)

/**
 * Validates and parses standard WireGuard (.conf) configuration files (e.g., Proton VPN Free exports).
 */
object WireGuardConfigParser {

    private val base64KeyRegex = Regex("""^[A-Za-z0-9+/]{42,43}=$""")

    fun parse(rawText: String): Result<ParsedWireGuardConfig> {
        var section = ""
        val interfaceMap = mutableMapOf<String, String>()
        val peerMap = mutableMapOf<String, String>()

        rawText.lineSequence().forEach { rawLine ->
            val line = rawLine.substringBefore("#").trim()
            if (line.isEmpty()) return@forEach
            if (line.startsWith("[") && line.endsWith("]")) {
                section = line.substring(1, line.length - 1).trim().lowercase()
                return@forEach
            }
            val eqIndex = line.indexOf('=')
            if (eqIndex <= 0) return@forEach
            val key = line.substring(0, eqIndex).trim().lowercase()
            val value = line.substring(eqIndex + 1).trim()
            when (section) {
                "interface" -> interfaceMap[key] = value
                "peer" -> peerMap[key] = value
            }
        }

        val privateKey = interfaceMap["privatekey"]
            ?: return Result.failure(IllegalArgumentException("Missing [Interface] PrivateKey"))
        if (!base64KeyRegex.matches(privateKey)) {
            return Result.failure(IllegalArgumentException("Invalid WireGuard PrivateKey format"))
        }

        val address = interfaceMap["address"]
            ?: return Result.failure(IllegalArgumentException("Missing [Interface] Address"))

        val publicKey = peerMap["publickey"]
            ?: return Result.failure(IllegalArgumentException("Missing [Peer] PublicKey"))
        if (!base64KeyRegex.matches(publicKey)) {
            return Result.failure(IllegalArgumentException("Invalid WireGuard PublicKey format"))
        }

        val endpoint = peerMap["endpoint"]
            ?: return Result.failure(IllegalArgumentException("Missing [Peer] Endpoint"))
        val (host, port) = parseEndpoint(endpoint)
            ?: return Result.failure(IllegalArgumentException("Invalid [Peer] Endpoint (expected host:port)"))

        val allowedIps = peerMap["allowedips"] ?: "0.0.0.0/0, ::/0"
        val dns = interfaceMap["dns"]
        val mtu = interfaceMap["mtu"]?.toIntOrNull()?.takeIf { it in 1280..1500 }
        val psk = peerMap["presharedkey"]?.takeIf { base64KeyRegex.matches(it) }
        val keepalive = peerMap["persistentkeepalive"]?.toIntOrNull()?.takeIf { it in 1..65535 }

        val sb = StringBuilder()
        sb.appendLine("[Interface]")
        sb.appendLine("PrivateKey = $privateKey")
        sb.appendLine("Address = $address")
        if (!dns.isNullOrBlank()) sb.appendLine("DNS = $dns")
        if (mtu != null) sb.appendLine("MTU = $mtu")
        sb.appendLine()
        sb.appendLine("[Peer]")
        sb.appendLine("PublicKey = $publicKey")
        if (!psk.isNullOrBlank()) sb.appendLine("PresharedKey = $psk")
        sb.appendLine("AllowedIPs = $allowedIps")
        sb.appendLine("Endpoint = $endpoint")
        if (keepalive != null) sb.appendLine("PersistentKeepalive = $keepalive")

        return Result.success(
            ParsedWireGuardConfig(
                privateKey = privateKey,
                address = address,
                dns = dns,
                mtu = mtu,
                publicKey = publicKey,
                presharedKey = psk,
                endpointHost = host,
                endpointPort = port,
                allowedIps = allowedIps,
                persistentKeepalive = keepalive,
                normalizedConfigText = sb.toString().trim()
            )
        )
    }

    private fun parseEndpoint(endpoint: String): Pair<String, Int>? {
        val lastColon = endpoint.lastIndexOf(':')
        if (lastColon <= 0 || lastColon == endpoint.lastIndex) return null
        val host = endpoint.substring(0, lastColon).removePrefix("[").removeSuffix("]").trim()
        val port = endpoint.substring(lastColon + 1).trim().toIntOrNull() ?: return null
        if (host.isEmpty() || port !in 1..65535) return null
        return host to port
    }
}
