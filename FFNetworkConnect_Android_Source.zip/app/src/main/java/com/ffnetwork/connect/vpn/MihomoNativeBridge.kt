package com.ffnetwork.connect.vpn

/**
 * Optional WhiteVPN/FlClash-compatible Mihomo JNI bridge detector.
 * When libclash.so is compiled via scripts/build-mihomo-core.sh (or GitHub Actions native job),
 * this bridge detects native availability cleanly without crashing zero-NDK builds.
 */
object MihomoNativeBridge {
    val isAvailable: Boolean by lazy {
        try {
            System.loadLibrary("clash")
            true
        } catch (_: UnsatisfiedLinkError) {
            false
        }
    }
}
