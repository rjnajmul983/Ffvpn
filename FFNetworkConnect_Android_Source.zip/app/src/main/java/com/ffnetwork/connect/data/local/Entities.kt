package com.ffnetwork.connect.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vpn_profiles")
data class VpnProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val providerId: String,
    val protocol: String, // "WireGuard" or "Mihomo"
    val endpointHost: String,
    val endpointPort: Int,
    val regionLabel: String,
    val encryptedConfig: String, // AES-256-GCM encrypted via Android Keystore
    val lastMeasuredRttMs: Long? = null,
    val createdAtEpochMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "diagnostic_records")
data class DiagnosticRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampEpochMs: Long = System.currentTimeMillis(),
    val connectionMode: String, // "DIRECT" or "VPN"
    val simOperator: String,
    val networkType: String,
    val dnsLatencyMs: Long,
    val avgRttMs: Long,
    val jitterMs: Double,
    val packetLossPercent: Double,
    val stabilityScore: Int,
    val internetReachable: Boolean,
    val probeEndpoint: String
)

@Entity(tableName = "connection_sessions")
data class ConnectionSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileName: String,
    val providerName: String,
    val protocol: String,
    val startedAtEpochMs: Long,
    val endedAtEpochMs: Long? = null,
    val rxBytes: Long = 0L,
    val txBytes: Long = 0L,
    val terminationReason: String = "Active"
)
