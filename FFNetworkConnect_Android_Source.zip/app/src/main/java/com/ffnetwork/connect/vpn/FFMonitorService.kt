package com.ffnetwork.connect.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.ffnetwork.connect.MainActivity
import com.ffnetwork.connect.R

/**
 * Foreground notification service showing honest VPN status and quick disconnect action.
 * Adheres to Android 14+ FOREGROUND_SERVICE_TYPE_SPECIAL_USE requirements.
 */
class FFMonitorService : Service() {

    companion object {
        const val CHANNEL_ID = "ff_vpn_status_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "com.ffnetwork.connect.action.START_MONITOR"
        const val ACTION_STOP = "com.ffnetwork.connect.action.STOP_MONITOR"
        const val ACTION_DISCONNECT_VPN = "com.ffnetwork.connect.action.DISCONNECT_VPN"
        const val EXTRA_PROFILE_NAME = "extra_profile_name"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISCONNECT_VPN -> {
                VpnController.getInstance(applicationContext).disconnectAsync("Disconnected from notification")
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                val profileName = intent?.getStringExtra(EXTRA_PROFILE_NAME) ?: "Active Tunnel"
                val notification = buildNotification(profileName)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.vpn_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.vpn_channel_desc)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(profileName: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val disconnectIntent = Intent(this, FFMonitorService::class.java).apply {
            action = ACTION_DISCONNECT_VPN
        }
        val disconnectPending = PendingIntent.getService(
            this, 1, disconnectIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("FF Network Connect Active")
            .setContentText("Tunnel: $profileName")
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(0, "Disconnect", disconnectPending)
            .build()
    }
}
