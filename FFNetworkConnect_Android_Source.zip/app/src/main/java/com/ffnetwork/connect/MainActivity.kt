package com.ffnetwork.connect

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.ffnetwork.connect.ui.MainViewModel
import com.ffnetwork.connect.ui.screens.*
import com.ffnetwork.connect.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FFNetworkConnectTheme {
                FFNetworkConnectRoot()
            }
        }
    }
}

@Composable
private fun FFNetworkConnectRoot(vm: MainViewModel = viewModel()) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: "dashboard"

    val vpnState by vm.vpnState.collectAsStateWithLifecycle()
    val networkInfo by vm.networkInfo.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val profiles by vm.profiles.collectAsStateWithLifecycle()
    val diagnosticsUi by vm.diagnosticsUi.collectAsStateWithLifecycle()
    val diagHistory by vm.diagnosticHistory.collectAsStateWithLifecycle()
    val sessionHistory by vm.sessionHistory.collectAsStateWithLifecycle()
    val importStatus by vm.importStatus.collectAsStateWithLifecycle()

    val selectedProfile = remember(profiles, settings.selectedProfileId) {
        profiles.firstOrNull { it.id == settings.selectedProfileId } ?: profiles.firstOrNull()
    }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            vm.toggleConnection()
        }
    }

    val runtimePermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { /* Permissions handled gracefully if denied */ }

    LaunchedEffect(Unit) {
        val perms = buildList {
            add(Manifest.permission.READ_PHONE_STATE)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        runtimePermLauncher.launch(perms.toTypedArray())
    }

    val bottomTabs = listOf(
        Triple("dashboard", "Home", Icons.Default.Dashboard),
        Triple("providers", "Providers", Icons.Default.Public),
        Triple("servers", "Servers", Icons.Default.Dns),
        Triple("diagnostics", "Diag", Icons.Default.Speed),
        Triple("gaming", "Gaming", Icons.Default.SportsEsports)
    )

    Scaffold(
        containerColor = NavyBackground,
        bottomBar = {
            NavigationBar(containerColor = NavySurface) {
                bottomTabs.forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = currentRoute == route,
                        onClick = {
                            navController.navigate(route) {
                                popUpTo("dashboard") { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NeonGreen,
                            selectedTextColor = NeonGreen,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary,
                            indicatorColor = NavySurfaceVariant
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "dashboard",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("dashboard") {
                DashboardScreen(
                    vpnState = vpnState,
                    networkInfo = networkInfo,
                    selectedProfile = selectedProfile,
                    diagnosticsUi = diagnosticsUi,
                    onToggleVpn = {
                        val prep = vm.prepareVpnPermission()
                        if (prep != null) vpnPermissionLauncher.launch(prep) else vm.toggleConnection()
                    },
                    onRunDiagnostics = vm::runNetworkDiagnostics,
                    onNavigate = { dest -> navController.navigate(dest) }
                )
            }
            composable("providers") {
                ProvidersScreen(
                    providers = vm.providers,
                    onGoToImport = { navController.navigate("servers") }
                )
            }
            composable("servers") {
                ServersScreen(
                    profiles = profiles,
                    selectedProfileId = selectedProfile?.id ?: -1L,
                    importStatus = importStatus,
                    onSelectProfile = vm::selectProfile,
                    onTestProfile = vm::testProfileLatency,
                    onDeleteProfile = vm::deleteProfile,
                    onImportWireGuard = vm::importWireGuardConfig,
                    onImportMihomo = vm::importMihomoYamlConfig,
                    onDismissBanner = vm::clearImportBanner
                )
            }
            composable("diagnostics") {
                DiagnosticsScreen(
                    networkInfo = networkInfo,
                    diagnosticsUi = diagnosticsUi,
                    history = diagHistory,
                    onRunProbe = vm::runNetworkDiagnostics,
                    onClearHistory = vm::clearDiagnosticsHistory
                )
            }
            composable("gaming") {
                GamingConnectivityScreen(
                    diagnosticsUi = diagnosticsUi,
                    profiles = profiles,
                    onRunProbe = vm::runNetworkDiagnostics,
                    onSelectBestProfile = vm::selectProfile
                )
            }
            composable("history") {
                ConnectionHistoryScreen(
                    sessions = sessionHistory,
                    onClearHistory = vm::clearSessionHistory
                )
            }
            composable("settings") {
                SettingsScreen(
                    settings = settings,
                    onDnsChange = vm::updatePreferredDns,
                    onIpv6Change = vm::updateIpv6,
                    onKillSwitchReminderChange = vm::updateKillSwitchReminder,
                    onSplitTunnelChange = vm::updateSplitTunnel,
                    onWipeAllData = vm::wipeAllLocalData
                )
            }
            composable("privacy") { PrivacyInfoScreen() }
            composable("about") { AboutScreen() }
        }
    }
}
