package com.ffnetwork.connect.security

/**
 * Security validator & sanitizer enforcing all WhiteVPN SECURITY-AUDIT.md protections:
 * - Finding #3: Mihomo DNS listener restricted to loopback (127.0.0.1:1053), never 0.0.0.0
 * - Finding #4: Drops keys/values containing line breaks to prevent YAML injection
 * - Finding #5 & #13: Rejects skip-cert-verify: true / allowInsecure=1 in imported configs
 * - Finding #7: Redacts sensitive secrets from diagnostic logs
 */
object ConfigSecurityValidator {

    data class ValidationResult(
        val isValid: Boolean,
        val warnings: List<String> = emptyList(),
        val errors: List<String> = emptyList()
    )

    private val sensitiveFieldRegex = Regex(
        pattern = """(?i)(private[-_]?key|preshared[-_]?key|password|secret|token|uuid|psk|short-id)\s*([:=])\s*([^\s,;&"']+)"""
    )

    fun validateSubscriptionUrl(url: String): ValidationResult {
        val trimmed = url.trim()
        if (!trimmed.startsWith("https://", ignoreCase = true)) {
            return ValidationResult(
                isValid = false,
                errors = listOf("Only HTTPS subscription URLs are permitted.")
            )
        }
        if (trimmed.contains("@") || trimmed.contains("#")) {
            return ValidationResult(
                isValid = false,
                errors = listOf("URL must not contain embedded credentials (userinfo) or fragments.")
            )
        }
        return ValidationResult(isValid = true)
    }

    fun validateMihomoYaml(rawYaml: String): ValidationResult {
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        if (rawYaml.length > 2 * 1024 * 1024) {
            errors.add("Configuration exceeds maximum safe size limit (2 MiB).")
        }

        // Finding #5 & #13: Detect disabled TLS certificate verification
        val skipCertRegex = Regex("""(?i)skip-cert-verify\s*:\s*true""")
        val allowInsecureRegex = Regex("""(?i)allowInsecure\s*[:=]\s*(true|1)""")
        if (skipCertRegex.containsMatchIn(rawYaml) || allowInsecureRegex.containsMatchIn(rawYaml)) {
            errors.add("Blocked: Configuration disables TLS certificate verification (skip-cert-verify/allowInsecure).")
        }

        // Finding #3: Prevent binding DNS resolver to 0.0.0.0
        val openDnsRegex = Regex("""(?i)listen\s*:\s*["']?0\.0\.0\.0:\d+""")
        if (openDnsRegex.containsMatchIn(rawYaml)) {
            errors.add("Blocked: DNS listener binds to 0.0.0.0 (must bind to 127.0.0.1 loopback only).")
        }

        return ValidationResult(
            isValid = errors.isEmpty(),
            warnings = warnings,
            errors = errors
        )
    }

    /**
     * Finding #4: Drops any map entry whose key or value contains newline/carriage-return characters.
     */
    fun sanitizeProxyMap(entries: Map<String, String>): Map<String, String> {
        return entries.filter { (k, v) ->
            !k.contains('\n') && !k.contains('\r') && !v.contains('\n') && !v.contains('\r')
        }
    }

    /**
     * Finding #3: Builds safe loopback-only Mihomo DNS block.
     */
    fun buildSafeLoopbackDnsYaml(upstreamDns: String): String {
        val cleanUpstream = upstreamDns.trim().replace("\n", "").replace("\r", "")
        return """
            dns:
              enable: true
              listen: 127.0.0.1:1053
              enhanced-mode: fake-ip
              nameserver:
                - $cleanUpstream
        """.trimIndent()
    }

    /**
     * Finding #7: Redacts credentials and private keys before logging or clipboard copy.
     */
    fun sanitizeForLog(input: String): String {
        return sensitiveFieldRegex.replace(input) { match ->
            "${match.groupValues[1]}${match.groupValues[2]}[REDACTED]"
        }
    }
}
