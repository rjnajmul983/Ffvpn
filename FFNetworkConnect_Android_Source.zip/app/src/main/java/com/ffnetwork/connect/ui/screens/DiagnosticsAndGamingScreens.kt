package com.ffnetwork.connect.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffnetwork.connect.data.local.DiagnosticRecordEntity
import com.ffnetwork.connect.data.local.VpnProfileEntity
import com.ffnetwork.connect.diagnostics.DeviceNetworkInfo
import com.ffnetwork.connect.ui.DiagnosticsUiState
import com.ffnetwork.connect.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DiagnosticsScreen(
    networkInfo: DeviceNetworkInfo,
    diagnosticsUi: DiagnosticsUiState,
    history: List<DiagnosticRecordEntity>,
    onRunProbe: () -> Unit,
    onClearHistory: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("MODE B — NETWORK DIAGNOSTICS", color = ElectricBlue, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text(
                "Operates 100% locally without any VPN server or cloud backend. Supports Grameenphone, Robi, Airtel, Banglalink, Teletalk, and Wi-Fi.",
                color = TextSecondary,
                fontSize = 12.sp
            )
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = NavySurface), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MetricItem("Detected SIM", networkInfo.normalizedBangladeshCarrier, Modifier.weight(1f))
                        MetricItem("Transport", networkInfo.networkType, Modifier.weight(1f))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MetricItem("Internet Validated", if (networkInfo.isValidatedInternet) "Yes" else "No", Modifier.weight(1f))
                        MetricItem("VPN Active", if (networkInfo.isVpnTransportActive) "Yes" else "No", Modifier.weight(1f))
                    }
                    Button(
                        onClick = onRunProbe,
                        enabled = !diagnosticsUi.isRunning,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (diagnosticsUi.isRunning) "Running Real Socket & DNS Probes..." else "Run Full Diagnostic Test")
                    }
                    Text(diagnosticsUi.statusMessage, color = TextSecondary, fontSize = 12.sp)
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("DIAGNOSTIC HISTORY (${history.size})", color = ElectricBlue, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                if (history.isNotEmpty()) {
                    TextButton(onClick = onClearHistory) { Text("Clear", color = AlertRed) }
                }
            }
        }

        items(history, key = { it.id }) { rec ->
            Card(colors = CardDefaults.cardColors(containerColor = NavySurface), shape = RoundedCornerShape(12.dp)) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            "${rec.connectionMode} • ${rec.simOperator} (${rec.networkType})",
                            color = if (rec.connectionMode == "VPN") NeonGreen else ElectricBlue,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        Text("Score ${rec.stabilityScore}/100", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        "RTT: ${rec.avgRttMs} ms  |  Jitter: ${rec.jitterMs} ms  |  Loss: ${"%.1f".format(rec.packetLossPercent)}%  |  DNS: ${rec.dnsLatencyMs} ms",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    Text(
                        "${formatTime(rec.timestampEpochMs)} • Endpoint: ${rec.probeEndpoint}",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
fun GamingConnectivityScreen(
    diagnosticsUi: DiagnosticsUiState,
    profiles: List<VpnProfileEntity>,
    onRunProbe: () -> Unit,
    onSelectBestProfile: (Long) -> Unit
) {
    val direct = diagnosticsUi.lastDirectResult
    val vpn = diagnosticsUi.lastVpnResult
    val bestProfile = profiles.filter { it.lastMeasuredRttMs != null }.minByOrNull { it.lastMeasuredRttMs!! }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("GAMING CONNECTIVITY ANALYSIS", color = ElectricBlue, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(
            "A VPN does not guarantee lower ping and can increase latency depending on routing. Compare measured Direct vs. VPN results below.",
            color = TextSecondary,
            fontSize = 12.sp
        )

        // Direct vs VPN Comparison Card
        Card(
            colors = CardDefaults.cardColors(containerColor = NavySurface),
            border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("DIRECT VS. VPN COMPARISON", color = ElectricBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("DIRECT CONNECTION", color = TextSecondary, fontSize = 11.sp)
                        Text(direct?.let { "${it.avgRttMs} ms RTT" } ?: "Not measured", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text(direct?.let { "Jitter ${it.jitterMs} ms • Loss ${"%.1f".format(it.packetLossPercent)}%" } ?: "--", color = TextSecondary, fontSize = 11.sp)
                        Text(direct?.let { "Stability: ${it.stabilityScore}/100" } ?: "--", color = NeonGreen, fontSize = 12.sp)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("VPN TUNNEL", color = TextSecondary, fontSize = 11.sp)
                        Text(vpn?.let { "${it.avgRttMs} ms RTT" } ?: "Not measured", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text(vpn?.let { "Jitter ${it.jitterMs} ms • Loss ${"%.1f".format(it.packetLossPercent)}%" } ?: "--", color = TextSecondary, fontSize = 11.sp)
                        Text(vpn?.let { "Stability: ${it.stabilityScore}/100" } ?: "--", color = NeonGreen, fontSize = 12.sp)
                    }
                }
                Button(onClick = onRunProbe, enabled = !diagnosticsUi.isRunning, modifier = Modifier.fillMaxWidth()) {
                    Text(if (diagnosticsUi.isRunning) "Measuring..." else "Measure Active Connection Now")
                }
            }
        }

        // Honest Latency Separation Card (Part 9 requirement)
        Card(colors = CardDefaults.cardColors(containerColor = NavySurface), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("LATENCY TRANSPARENCY", color = AlertAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("A. VPN Tunnel Latency: ${vpn?.avgRttMs?.let { "$it ms" } ?: "Not measured yet"}", color = TextPrimary, fontSize = 12.sp)
                Text("B. General Internet Latency: ${direct?.avgRttMs?.let { "$it ms" } ?: "Not measured yet"}", color = TextPrimary, fontSize = 12.sp)
                Text(
                    "C. Actual Game-Server Latency (e.g., Free Fire): Not directly measured. General Internet RTT is never mislabeled as Free Fire ping.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // Best Server Recommendation
        Card(colors = CardDefaults.cardColors(containerColor = NavySurface), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("BEST-SERVER RECOMMENDATION", color = NeonGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                if (bestProfile != null) {
                    Text(
                        "Lowest measured endpoint RTT: ${bestProfile.name} (${bestProfile.lastMeasuredRttMs} ms)",
                        color = TextPrimary,
                        fontSize = 13.sp
                    )
                    Button(onClick = { onSelectBestProfile(bestProfile.id) }) {
                        Text("Select Recommended Server")
                    }
                } else {
                    Text(
                        "Import and ping your authorized servers on the Servers tab to get a measured recommendation.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

private fun formatTime(epochMs: Long): String =
    SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(epochMs))
