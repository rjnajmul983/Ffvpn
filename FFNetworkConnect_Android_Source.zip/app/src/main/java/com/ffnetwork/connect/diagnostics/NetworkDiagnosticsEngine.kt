package com.ffnetwork.connect.diagnostics

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs
import kotlin.math.roundToInt

data class DiagnosticProbeResult(
    val internetReachable: Boolean,
    val dnsLatencyMs: Long,
    val rttSamplesMs: List<Long>,
    val avgRttMs: Long,
    val minRttMs: Long,
    val maxRttMs: Long,
    val jitterMs: Double,
    val packetLossPercent: Double,
    val stabilityScore: Int,
    val probeEndpoint: String,
    val interruptionCount: Int
)

/**
 * Pure local network diagnostics engine (zero backend required).
 * Uses real DNS resolution and bounded TCP connect probes against approved public endpoints
 * (Cloudflare 1.1.1.1:443 / Google 8.8.8.8:443) to measure general Internet RTT, jitter, and loss.
 * Never mislabels general Internet RTT as game-server ping.
 */
object NetworkDiagnosticsEngine {

    suspend fun runFullProbe(
        host: String = "1.1.1.1",
        port: Int = 443,
        dnsTarget: String = "cloudflare.com",
        sampleCount: Int = 6,
        timeoutMs: Int = 2000
    ): DiagnosticProbeResult = withContext(Dispatchers.IO) {
        val dnsLatency = measureDnsMs(dnsTarget)
        val samples = mutableListOf<Long>()
        var failures = 0

        for (i in 0 until sampleCount) {
            val rtt = measureTcpConnectMs(host, port, timeoutMs)
            if (rtt != null) {
                samples.add(rtt)
            } else {
                failures++
            }
            if (i < sampleCount - 1) delay(120L)
        }

        val packetLoss = if (sampleCount > 0) (failures.toDouble() / sampleCount.toDouble()) * 100.0 else 100.0
        val avgRtt = if (samples.isNotEmpty()) samples.average().toLong() else -1L
        val minRtt = samples.minOrNull() ?: -1L
        val maxRtt = samples.maxOrNull() ?: -1L
        val jitter = calculateJitter(samples)
        val score = computeStabilityScore(
            avgRttMs = avgRtt,
            jitterMs = jitter,
            packetLossPercent = packetLoss,
            reachable = samples.isNotEmpty()
        )

        DiagnosticProbeResult(
            internetReachable = samples.isNotEmpty(),
            dnsLatencyMs = dnsLatency,
            rttSamplesMs = samples,
            avgRttMs = avgRtt,
            minRttMs = minRtt,
            maxRttMs = maxRtt,
            jitterMs = jitter,
            packetLossPercent = packetLoss,
            stabilityScore = score,
            probeEndpoint = "$host:$port",
            interruptionCount = failures
        )
    }

    suspend fun measureEndpointTcpRtt(host: String, port: Int, timeoutMs: Int = 2500): Long? =
        withContext(Dispatchers.IO) {
            measureTcpConnectMs(host, port, timeoutMs)
        }

    private fun measureDnsMs(hostname: String): Long {
        val start = System.nanoTime()
        return try {
            InetAddress.getAllByName(hostname)
            ((System.nanoTime() - start) / 1_000_000L).coerceAtLeast(1L)
        } catch (_: Exception) {
            -1L
        }
    }

    private fun measureTcpConnectMs(host: String, port: Int, timeoutMs: Int): Long? {
        val socket = Socket()
        return try {
            val start = System.nanoTime()
            socket.connect(InetSocketAddress(host, port), timeoutMs)
            ((System.nanoTime() - start) / 1_000_000L).coerceAtLeast(1L)
        } catch (_: Exception) {
            null
        } finally {
            runCatching { socket.close() }
        }
    }

    /**
     * Mean absolute consecutive RTT difference (ms).
     */
    fun calculateJitter(samples: List<Long>): Double {
        if (samples.size < 2) return 0.0
        var diffSum = 0.0
        for (i in 1 until samples.size) {
            diffSum += abs(samples[i] - samples[i - 1]).toDouble()
        }
        return (diffSum / (samples.size - 1) * 10.0).roundToInt() / 10.0
    }

    /**
     * Gaming stability score (0-100) derived strictly from measured RTT, jitter, and packet loss.
     */
    fun computeStabilityScore(
        avgRttMs: Long,
        jitterMs: Double,
        packetLossPercent: Double,
        reachable: Boolean
    ): Int {
        if (!reachable || avgRttMs < 0) return 0
        var score = 100.0
        // Penalize latency above 40ms
        score -= ((avgRttMs - 40L).coerceAtLeast(0L) * 0.25)
        // Penalize jitter (critical for real-time gaming)
        score -= (jitterMs * 1.2)
        // Heavily penalize packet loss
        score -= (packetLossPercent * 2.0)
        return score.roundToInt().coerceIn(0, 100)
    }
}
