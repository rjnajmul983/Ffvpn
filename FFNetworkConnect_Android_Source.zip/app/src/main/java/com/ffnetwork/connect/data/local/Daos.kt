package com.ffnetwork.connect.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface VpnProfileDao {
    @Query("SELECT * FROM vpn_profiles ORDER BY createdAtEpochMs DESC")
    fun observeAll(): Flow<List<VpnProfileEntity>>

    @Query("SELECT * FROM vpn_profiles WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): VpnProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(profile: VpnProfileEntity): Long

    @Query("UPDATE vpn_profiles SET lastMeasuredRttMs = :rttMs WHERE id = :id")
    suspend fun updateRtt(id: Long, rttMs: Long?)

    @Query("DELETE FROM vpn_profiles WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM vpn_profiles")
    suspend fun deleteAll()
}

@Dao
interface DiagnosticRecordDao {
    @Query("SELECT * FROM diagnostic_records ORDER BY timestampEpochMs DESC LIMIT 100")
    fun observeRecent(): Flow<List<DiagnosticRecordEntity>>

    @Insert
    suspend fun insert(record: DiagnosticRecordEntity): Long

    @Query("DELETE FROM diagnostic_records")
    suspend fun clearAll()
}

@Dao
interface ConnectionSessionDao {
    @Query("SELECT * FROM connection_sessions ORDER BY startedAtEpochMs DESC LIMIT 100")
    fun observeRecent(): Flow<List<ConnectionSessionEntity>>

    @Insert
    suspend fun insert(session: ConnectionSessionEntity): Long

    @Query("UPDATE connection_sessions SET endedAtEpochMs = :endedAt, rxBytes = :rx, txBytes = :tx, terminationReason = :reason WHERE id = :id")
    suspend fun closeSession(id: Long, endedAt: Long, rx: Long, tx: Long, reason: String)

    @Query("DELETE FROM connection_sessions")
    suspend fun clearAll()
}
