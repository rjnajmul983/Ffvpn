package com.ffnetwork.connect.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffnetwork.connect.BuildConfig
import com.ffnetwork.connect.data.local.ConnectionSessionEntity
import com.ffnetwork.connect.data.local.UserSettings
import com.ffnetwork.connect.ui.theme.*
import com.ffnetwork.connect.vpn.MihomoNativeBridge
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ConnectionHistoryScreen(
    sessions: List<ConnectionSessionEntity>,
    onClearHistory: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("CONNECTION HISTORY", color = ElectricBlue, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                if (sessions.isNotEmpty()) {
                    TextButton(onClick = onClearHistory) { Text("Clear All", color = AlertRed) }
                }
            }
        }
        if (sessions.isEmpty()) {
            item {
                Text("No VPN sessions recorded yet.", color = TextSecondary, fontSize = 13.sp)
            }
        } else {
            items(sessions, key = { it.id }) { s ->
                Card(colors = CardDefaults.cardColors(containerColor = NavySurface), shape = RoundedCornerShape(12.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${s.profileName} (${s.protocol})", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("Started: ${fmt(s.startedAtEpochMs)} • Status: ${s.terminationReason}", color = TextSecondary, fontSize = 12.sp)
                        Text("Traffic: ↓ ${s.rxBytes / 1024} KB  ↑ ${s.txBytes / 1024} KB", color = NeonGreen, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    settings: UserSettings,
    onDnsChange: (String) -> Unit,
    onIpv6Change: (Boolean) -> Unit,
    onKillSwitchReminderChange: (Boolean) -> Unit,
    onSplitTunnelChange: (String, Set<String>) -> Unit,
    onWipeAllData: () -> Unit
) {
    val context = LocalContext.current
    var splitPackagesText by remember(settings.splitTunnelPackages) {
        mutableStateOf(settings.splitTunnelPackages.joinToString(", "))
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("SETTINGS", color = ElectricBlue, fontSize = 15.sp, fontWeight = FontWeight.Bold)

        // DNS Selection
        Card(colors = CardDefaults.cardColors(containerColor = NavySurface), shape = RoundedCornerShape(14.dp)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Preferred Diagnostic & Fallback DNS", color = TextPrimary, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("1.1.1.1" to "Cloudflare", "8.8.8.8" to "Google", "9.9.9.9" to "Quad9").forEach { (ip, label) ->
                        FilterChip(
                            selected = settings.preferredDns == ip,
                            onClick = { onDnsChange(ip) },
                            label = { Text("$label ($ip)", fontSize = 11.sp) }
                        )
                    }
                }
            }
        }

        // IPv6 & System Kill Switch
        Card(colors = CardDefaults.cardColors(containerColor = NavySurface), shape = RoundedCornerShape(14.dp)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Allow IPv6 Routing", color = TextPrimary)
                    Switch(checked = settings.ipv6Enabled, onCheckedChange = onIpv6Change)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Android System Kill Switch Reminder", color = TextPrimary)
                    Switch(checked = settings.killSwitchReminder, onCheckedChange = onKillSwitchReminderChange)
                }
                OutlinedButton(
                    onClick = {
                        runCatching { context.startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open Android VPN Settings (Always-On / Block Without VPN)")
                }
            }
        }

        // Per-App Split Tunneling
        Card(colors = CardDefaults.cardColors(containerColor = NavySurface), shape = RoundedCornerShape(14.dp)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Per-App Routing (Split Tunnel)", color = TextPrimary, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("ALL_APPS" to "All", "EXCLUDE_SELECTED" to "Exclude", "ONLY_SELECTED" to "Only").forEach { (mode, label) ->
                        FilterChip(
                            selected = settings.splitTunnelMode == mode,
                            onClick = { onSplitTunnelChange(mode, settings.splitTunnelPackages) },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                }
                OutlinedTextField(
                    value = splitPackagesText,
                    onValueChange = { splitPackagesText = it },
                    label = { Text("Package names (comma-separated, e.g. com.dts.freefireth)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = {
                    val parsed = splitPackagesText.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
                    onSplitTunnelChange(settings.splitTunnelMode, parsed)
                }) {
                    Text("Save Split-Tunnel Packages")
                }
            }
        }

        // Zero-Cost Local Data Deletion
        Card(colors = CardDefaults.cardColors(containerColor = NavySurface), shape = RoundedCornerShape(14.dp)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Local Storage & Keystore Vault", color = AlertRed, fontWeight = FontWeight.Bold)
                Text(
                    "Deletes all imported VPN configs, Keystore AES-256-GCM keys, diagnostic logs, and session history from this device.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Button(
                    onClick = onWipeAllData,
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Wipe All Local Data & Keys")
                }
            }
        }
    }
}

@Composable
fun PrivacyInfoScreen() {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("PRIVACY & SECURITY DISCLOSURES", color = ElectricBlue, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        InfoCard(
            "Zero Telemetry & Zero Backend",
            "FF Network Connect has no analytics SDK, no advertising ID permissions, and no remote backend server. All settings, profiles, and diagnostic records stay locally on your phone."
        )
        InfoCard(
            "Hardware-Backed Local Encryption",
            "Imported WireGuard private keys and Mihomo profiles are encrypted with Android Keystore AES-256-GCM. Android cloud backup and device-to-device data transfer are disabled."
        )
        InfoCard(
            "Free VPN Provider Risks",
            "When you connect to a third-party free VPN provider (such as Proton VPN Free), your internet traffic exits through that provider's servers under their privacy policy and terms. Free plans may change availability or limits without notice."
        )
        InfoCard(
            "Operator & Legal Compliance",
            "This app does not modify carrier APN settings, does not include DPI circumvention or traffic disguise, and respects Bangladeshi SIM operator terms and game-service rules."
        )
    }
}

@Composable
fun AboutScreen() {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("ABOUT FF NETWORK CONNECT", color = ElectricBlue, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        InfoCard(
            "Application Details",
            "Package: com.ffnetwork.connect\nVersion: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})\nWireGuard Engine: Official WireGuard GoBackend (Active)\nOptional Mihomo Native Core: ${if (MihomoNativeBridge.isAvailable) "Loaded (libclash.so)" else "Not bundled (WireGuard mode active)"}"
        )
        InfoCard(
            "Open-Source License (GPL-3.0-only)",
            "FF Network Connect is free open-source software licensed under GNU GPL v3.0 (GPL-3.0-only), preserving full license compliance and upstream attribution to WhiteDNS/WhiteVPN (https://github.com/WhiteDNS/WhiteVPN)."
        )
        InfoCard(
            "Third-Party Attributions",
            "• WhiteDNS/WhiteVPN (GPL-3.0-only) — Lifecycle architecture & security audit mitigations\n• WireGuard-Android Tunnel (Apache-2.0) — Official userspace WireGuard tunnel engine\n• AndroidX, Jetpack Compose, Room, DataStore, Kotlin Coroutines (Apache-2.0)"
        )
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = NavySurface), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(body, color = TextPrimary, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

private fun fmt(epochMs: Long): String =
    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(epochMs))
