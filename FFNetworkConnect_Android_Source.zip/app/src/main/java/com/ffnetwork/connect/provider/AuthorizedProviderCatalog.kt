package com.ffnetwork.connect.provider

data class FreeVpnProvider(
    val id: String,
    val name: String,
    val officialWebsite: String,
    val freePlanAvailable: Boolean,
    val manualConfigImportSupportedOnFree: Boolean,
    val supportedProtocols: List<String>,
    val configurationMethod: String,
    val serverAvailabilitySummary: String,
    val privacyPolicyUrl: String,
    val usageRestrictions: String,
    val lastVerifiedDate: String
)

/**
 * Verified catalog of official, legitimate free VPN providers.
 * No scraped proxy lists, no stolen credentials, no fabricated server endpoints.
 * Availability and terms are subject to provider changes; users import their own authorized configs.
 */
object AuthorizedProviderCatalog {

    val providers: List<FreeVpnProvider> = listOf(
        FreeVpnProvider(
            id = "proton_vpn_free",
            name = "Proton VPN (Free Plan)",
            officialWebsite = "https://protonvpn.com/free-vpn",
            freePlanAvailable = true,
            manualConfigImportSupportedOnFree = true,
            supportedProtocols = listOf("WireGuard"),
            configurationMethod = "Sign in at account.protonvpn.com -> Downloads -> WireGuard configuration -> Download .conf -> Import into FF Network Connect.",
            serverAvailabilitySummary = "Free servers in rotating countries (e.g., NL, US, JP, RO, PL depending on current Proton Free pool).",
            privacyPolicyUrl = "https://protonvpn.com/privacy-policy",
            usageRestrictions = "Unlimited data, no ads, 1 active connection on Free plan; only VPN Accelerator option available; P2P/streaming restricted on Free.",
            lastVerifiedDate = "2026-11-25"
        ),
        FreeVpnProvider(
            id = "windscribe_free",
            name = "Windscribe (Free Plan)",
            officialWebsite = "https://windscribe.com/features/use-for-free",
            freePlanAvailable = true,
            manualConfigImportSupportedOnFree = false,
            supportedProtocols = listOf("WireGuard (Official App)", "OpenVPN (Pro Config)"),
            configurationMethod = "Manual WireGuard .conf generator requires a paid Pro or Build-A-Plan subscription. Not importable on Free tier.",
            serverAvailabilitySummary = "10 free locations via official Windscribe app only.",
            privacyPolicyUrl = "https://windscribe.com/privacy",
            usageRestrictions = "10 GB/month with verified email; manual third-party WireGuard config export is UNAVAILABLE on the Free plan.",
            lastVerifiedDate = "2026-11-25"
        ),
        FreeVpnProvider(
            id = "cloudflare_warp",
            name = "Cloudflare WARP (1.1.1.1)",
            officialWebsite = "https://developers.cloudflare.com/warp-client/",
            freePlanAvailable = true,
            manualConfigImportSupportedOnFree = false,
            supportedProtocols = listOf("WireGuard / MASQUE (Official Client)"),
            configurationMethod = "Official Cloudflare 1.1.1.1 app only. Cloudflare does not provide an official third-party WireGuard .conf export.",
            serverAvailabilitySummary = "Global Cloudflare Anycast edge network (not a geo-location switcher).",
            privacyPolicyUrl = "https://www.cloudflare.com/application/privacypolicy/",
            usageRestrictions = "Unlimited consumer WARP traffic via official app; unofficial key extraction is not supported here.",
            lastVerifiedDate = "2026-11-25"
        ),
        FreeVpnProvider(
            id = "custom_byoc",
            name = "Authorized Custom WireGuard / Mihomo",
            officialWebsite = "https://www.wireguard.com/",
            freePlanAvailable = true,
            manualConfigImportSupportedOnFree = true,
            supportedProtocols = listOf("WireGuard (.conf)", "Mihomo YAML (with optional native core)"),
            configurationMethod = "Import any legally authorized WireGuard .conf file or Mihomo YAML profile from your own provider.",
            serverAvailabilitySummary = "Depends on your authorized provider or personal tunnel.",
            privacyPolicyUrl = "https://www.wireguard.com/",
            usageRestrictions = "Must comply with provider terms and local law. Configs with skip-cert-verify: true or YAML injection are blocked.",
            lastVerifiedDate = "2026-11-25"
        )
    )
}
