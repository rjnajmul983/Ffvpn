package com.ffnetwork.connect.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "ff_network_prefs")

data class UserSettings(
    val selectedProfileId: Long = -1L,
    val preferredDns: String = "1.1.1.1",
    val ipv6Enabled: Boolean = true,
    val killSwitchReminder: Boolean = false,
    val splitTunnelMode: String = "ALL_APPS", // ALL_APPS, EXCLUDE_SELECTED, ONLY_SELECTED
    val splitTunnelPackages: Set<String> = emptySet(),
    val privacyAccepted: Boolean = false
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val SELECTED_PROFILE_ID = longPreferencesKey("selected_profile_id")
        val PREFERRED_DNS = stringPreferencesKey("preferred_dns")
        val IPV6_ENABLED = booleanPreferencesKey("ipv6_enabled")
        val KILL_SWITCH_REMINDER = booleanPreferencesKey("kill_switch_reminder")
        val SPLIT_TUNNEL_MODE = stringPreferencesKey("split_tunnel_mode")
        val SPLIT_TUNNEL_PACKAGES = stringSetPreferencesKey("split_tunnel_packages")
        val PRIVACY_ACCEPTED = booleanPreferencesKey("privacy_accepted")
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        UserSettings(
            selectedProfileId = prefs[Keys.SELECTED_PROFILE_ID] ?: -1L,
            preferredDns = prefs[Keys.PREFERRED_DNS] ?: "1.1.1.1",
            ipv6Enabled = prefs[Keys.IPV6_ENABLED] ?: true,
            killSwitchReminder = prefs[Keys.KILL_SWITCH_REMINDER] ?: false,
            splitTunnelMode = prefs[Keys.SPLIT_TUNNEL_MODE] ?: "ALL_APPS",
            splitTunnelPackages = prefs[Keys.SPLIT_TUNNEL_PACKAGES] ?: emptySet(),
            privacyAccepted = prefs[Keys.PRIVACY_ACCEPTED] ?: false
        )
    }

    suspend fun setSelectedProfileId(id: Long) {
        context.dataStore.edit { it[Keys.SELECTED_PROFILE_ID] = id }
    }

    suspend fun setPreferredDns(dns: String) {
        context.dataStore.edit { it[Keys.PREFERRED_DNS] = dns }
    }

    suspend fun setIpv6Enabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.IPV6_ENABLED] = enabled }
    }

    suspend fun setKillSwitchReminder(enabled: Boolean) {
        context.dataStore.edit { it[Keys.KILL_SWITCH_REMINDER] = enabled }
    }

    suspend fun setSplitTunnel(mode: String, packages: Set<String>) {
        context.dataStore.edit {
            it[Keys.SPLIT_TUNNEL_MODE] = mode
            it[Keys.SPLIT_TUNNEL_PACKAGES] = packages
        }
    }

    suspend fun setPrivacyAccepted(accepted: Boolean) {
        context.dataStore.edit { it[Keys.PRIVACY_ACCEPTED] = accepted }
    }

    suspend fun clearAll() {
        context.dataStore.edit { it.clear() }
    }
}
