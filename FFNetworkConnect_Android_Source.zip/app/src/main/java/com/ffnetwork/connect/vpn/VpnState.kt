package com.ffnetwork.connect.vpn

enum class LifecyclePhase {
    INACTIVE,
    ESTABLISHING,
    ACTIVE,
    RELEASING,
    ERROR
}

data class VpnRuntimeState(
    val phase: LifecyclePhase = LifecyclePhase.INACTIVE,
    val activeProfileId: Long? = null,
    val activeProfileName: String = "None",
    val activeProviderName: String = "No Provider Selected",
    val protocol: String = "WireGuard",
    val connectedSinceEpochMs: Long? = null,
    val rxBytes: Long = 0L,
    val txBytes: Long = 0L,
    val errorMessage: String? = null,
    val mihomoNativeAvailable: Boolean = false
)
