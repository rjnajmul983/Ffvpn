package com.ffnetwork.connect

import com.ffnetwork.connect.diagnostics.NetworkDiagnosticsEngine
import com.ffnetwork.connect.diagnostics.SimAndNetworkDetector
import com.ffnetwork.connect.provider.WireGuardConfigParser
import com.ffnetwork.connect.security.ConfigSecurityValidator
import org.junit.Assert.*
import org.junit.Test

class SecurityAndDiagnosticsTest {

    @Test
    fun mihomoDnsMustBindLoopbackOnly_finding3() {
        val safeYaml = ConfigSecurityValidator.buildSafeLoopbackDnsYaml("1.1.1.1")
        assertTrue(safeYaml.contains("listen: 127.0.0.1:1053"))
        assertFalse(safeYaml.contains("0.0.0.0"))

        val unsafeYaml = "dns:\n  enable: true\n  listen: 0.0.0.0:1053\n"
        val res = ConfigSecurityValidator.validateMihomoYaml(unsafeYaml)
        assertFalse(res.isValid)
    }

    @Test
    fun yamlInjectionWithNewlineKeyIsDropped_finding4() {
        val malicious = mapOf(
            "name" to "LegitServer",
            "server\nskip-cert-verify: true" to "example.com",
            "port" to "443"
        )
        val sanitized = ConfigSecurityValidator.sanitizeProxyMap(malicious)
        assertEquals(2, sanitized.size)
        assertFalse(sanitized.keys.any { it.contains("\n") })
    }

    @Test
    fun importedYamlDisablingCertVerifyIsBlocked_findings5and13() {
        val yaml = "proxies:\n  - name: test\n    skip-cert-verify: true\n"
        val result = ConfigSecurityValidator.validateMihomoYaml(yaml)
        assertFalse(result.isValid)
    }

    @Test
    fun sensitiveFieldsAreRedactedFromLogs_finding7() {
        val raw = "PrivateKey = AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA= password: mySecret123"
        val sanitized = ConfigSecurityValidator.sanitizeForLog(raw)
        assertFalse(sanitized.contains("mySecret123"))
        assertFalse(sanitized.contains("AAAA"))
        assertTrue(sanitized.contains("[REDACTED]"))
    }

    @Test
    fun wireGuardParserAcceptsValidProtonFormat() {
        val sample = """
            [Interface]
            PrivateKey = AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=
            Address = 10.2.0.2/32
            DNS = 10.2.0.1

            [Peer]
            PublicKey = BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=
            AllowedIPs = 0.0.0.0/0, ::/0
            Endpoint = 198.51.100.10:51820
        """.trimIndent()
        val parsed = WireGuardConfigParser.parse(sample)
        assertTrue(parsed.isSuccess)
        assertEquals("198.51.100.10", parsed.getOrThrow().endpointHost)
        assertEquals(51820, parsed.getOrThrow().endpointPort)
    }

    @Test
    fun bangladeshCarrierNormalizationWorks() {
        assertEquals("Grameenphone", SimAndNetworkDetector.normalizeBangladeshOperator("GP 4G"))
        assertEquals("Robi", SimAndNetworkDetector.normalizeBangladeshOperator("Robi Axiata"))
        assertEquals("Airtel", SimAndNetworkDetector.normalizeBangladeshOperator("Airtel BD"))
        assertEquals("Banglalink", SimAndNetworkDetector.normalizeBangladeshOperator("Banglalink"))
        assertEquals("Teletalk", SimAndNetworkDetector.normalizeBangladeshOperator("Teletalk 4G"))
    }

    @Test
    fun jitterAndStabilityScoreCalculationsAreAccurate() {
        val jitter = NetworkDiagnosticsEngine.calculateJitter(listOf(40L, 50L, 45L, 55L))
        assertEquals(8.3, jitter, 0.1)
        val highScore = NetworkDiagnosticsEngine.computeStabilityScore(40L, 2.0, 0.0, true)
        val lowScore = NetworkDiagnosticsEngine.computeStabilityScore(220L, 35.0, 20.0, true)
        assertTrue(highScore > 90)
        assertTrue(lowScore < 30)
        assertEquals(0, NetworkDiagnosticsEngine.computeStabilityScore(-1L, 0.0, 100.0, false))
    }
}
