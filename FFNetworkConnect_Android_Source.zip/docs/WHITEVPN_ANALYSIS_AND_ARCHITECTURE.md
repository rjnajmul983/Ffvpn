# FF Network Connect — Complete Engineering Analysis, Security Audit, License & Test Documentation

**Project**: FF Network Connect (`com.ffnetwork.connect`)  
**Budget**: Strictly Zero ($0)  
**Upstream Reference**: [WhiteDNS/WhiteVPN](https://github.com/WhiteDNS/WhiteVPN) (verified at commit `d6349ea`, GPL-3.0-only)  
**License**: GNU General Public License v3.0 (`GPL-3.0-only`)  
**Last Verified**: 2026-11-25

---

## 1. WhiteVPN Source Inventory & Architecture Analysis

Inspection of [WhiteDNS/WhiteVPN](https://github.com/WhiteDNS/WhiteVPN) (`main` branch, commit `d6349ea`, 52 commits) confirms that WhiteVPN is an Android / Android TV VPN client (`com.whitedns.vpn`) powered by a maintained fork of **Mihomo v1.19.34** ([WhiteDNS/mihomo](https://github.com/WhiteDNS/WhiteVPN)) bridged through the **FlClash** Android JNI integration ([WhiteDNS/FlClash](https://github.com/WhiteDNS/WhiteVPN)).

| Path / Module in WhiteVPN | Purpose & Dependencies | Role in WhiteVPN | Reuse Decision in FF Network Connect |
|---|---|---|---|
| [`build.gradle.kts`](https://github.com/WhiteDNS/WhiteVPN/blob/main/build.gradle.kts) | AGP 8.7.3, Kotlin 2.2.0, `com.google.gms.google-services` 4.5.0 | Root Gradle plugin config | **Modified**: Kept AGP 8.7.3 + Kotlin 2.x; **removed** `google-services` / Firebase Analytics to eliminate AD_ID permissions |
| [`settings.gradle.kts`](https://github.com/WhiteDNS/WhiteVPN/blob/main/settings.gradle.kts) | `rootProject.name = "WhiteDNSVPN"`, `include(":app")` | Single-module Gradle setup | **Modified**: Renamed to `FFNetworkConnect`, strict `FAIL_ON_PROJECT_REPOS` preserved |
| [`Makefile`](https://github.com/WhiteDNS/WhiteVPN/blob/main/Makefile) | Targets: `test`, `debug`, `mihomo-core`, `release`, `clean` | Invokes `./scripts/build-flclash-core.sh` and `./gradlew` | **Replaced** with zero-budget GitHub Actions CI (`build-apk.yml`) + Termux helper script |
| [`CONTEXT.md`](https://github.com/WhiteDNS/WhiteVPN/blob/main/CONTEXT.md) | Formal lifecycle glossary (`Inactive`, `Establishing`, `Active`, `Releasing`, `Data Plane Ownership`, `Route Health`) | Prevents conflating UI state with actual tunnel readiness | **Reused**: Adopted directly in `VpnState.kt` and `VpnController.kt` |
| [`SECURITY-AUDIT.md`](https://github.com/WhiteDNS/WhiteVPN/blob/main/SECURITY-AUDIT.md) | 15-finding security audit at commit `a23a317` (2026-08-01) | Security baseline & regression test blueprint | **Reused & Hardened**: All fixed mitigations preserved; unresolved Findings #13, #14, #15 resolved |
| `scripts/build-flclash-core.sh` & `native/` | Checks out pinned `WhiteDNS/FlClash` + `WhiteDNS/mihomo`, compiles Go/CGo JNI `.so` libraries for `armeabi-v7a`, `arm64-v8a`, `x86`, `x86_64` (16 KB page aligned) | Native networking engine build | **Optionalized**: Replaced mandatory NDK/Go compile with official Maven Central `com.wireguard.android:tunnel` (Apache-2.0) for zero-NDK builds, plus optional `MihomoNativeBridge.kt` |
| `SubConv/` | Share-link parser (VLESS, VMess, Trojan, Shadowsocks, Hysteria2, WireGuard/AmneziaWG) | Subscription normalization | **Replaced for Mode A** with strict `WireGuardConfigParser.kt` + `ConfigSecurityValidator.kt` |
| `app/` (Kotlin Android) | `VpnService`, `MainActivity`, `WhiteDnsTileService`, `CleanIpScanner`, `MihomoRuntimeConfigBuilder`, `byedpi_bridge.cpp` | UI, VPN lifecycle, ByeDPI bridge | **Rebuilt cleanly** in Jetpack Compose Material 3 (`com.ffnetwork.connect`); **excluded** `byedpi_bridge.cpp` (no DPI circumvention) and `CleanIpScanner` |
| [`LICENSE`](https://github.com/WhiteDNS/WhiteVPN/blob/main/LICENSE) | `GPL-3.0-only` | Copyleft license terms | **Preserved**: FF Network Connect is licensed under `GPL-3.0-only` with full attribution in `THIRD_PARTY_NOTICES.md` |

### Application Flow in FF Network Connect
`Jetpack Compose UI (9 Screens)` → `MainViewModel (StateFlow)` → `VpnController / NetworkDiagnosticsEngine / Room + DataStore` → `SecureVault (Android Keystore AES-256-GCM)` → `WireGuard GoBackend (Android VpnService)` → `Android TUN Interface`.

---

## 2. Security Audit Verification (WhiteVPN `SECURITY-AUDIT.md` Classification)

Every finding from [WhiteVPN/SECURITY-AUDIT.md](https://github.com/WhiteDNS/WhiteVPN/blob/main/SECURITY-AUDIT.md) was audited and mapped into FF Network Connect:

| # | Upstream Finding | Severity | Upstream Status | FF Network Connect Status |
|---|---|---|---|---|
| 1 | Hardcoded AES-GCM payload keys in source & git history | High | Mitigated (rotation needed) | **Fixed**: No hardcoded keys; all secrets encrypted per-device with hardware-backed Android Keystore AES-256-GCM (`SecureVault.kt`) |
| 2 | Clean-IP speed test TLS without hostname verification | High | Fixed | **Not Applicable**: Clean-IP scanner removed; standard system trust anchors enforced in `network_security_config.xml` |
| 3 | Mihomo DNS resolver bound to `0.0.0.0:1053` | Medium | Fixed | **Fixed + Tested**: `ConfigSecurityValidator` blocks `0.0.0.0` and binds loopback `127.0.0.1:1053` (`mihomoDnsMustBindLoopbackOnly_finding3`) |
| 4 | YAML injection via newline in Clash/Xray JSON keys | Medium | Fixed | **Fixed + Tested**: `sanitizeProxyMap()` drops any key/value with `
`/`` (`yamlInjectionWithNewlineKeyIsDropped_finding4`) |
| 5 | Imported links silently disabling cert verification | Medium | Fixed | **Fixed + Tested**: `allowInsecure` / `skip-cert-verify: true` rejected (`importedYamlDisablingCertVerifyIsBlocked_findings5and13`) |
| 6 | Device-to-device transfer not disabled (`dataExtractionRules`) | Medium | Fixed | **Fixed**: `allowBackup="false"` + explicit `data_extraction_rules.xml` & `backup_rules.xml` excluding all domains |
| 7 | Incomplete log redaction | Low | Fixed | **Fixed + Tested**: Regex redacts `private-key`, `preshared-key`, `password`, `secret`, `token`, `uuid`, `psk` (`sensitiveFieldsAreRedactedFromLogs_finding7`) |
| 8 | Broadcast receivers implicitly exported below API 33 | Low | Fixed | **Fixed**: Uses `StateFlow` in-process and non-exported `FFMonitorService` + `GoBackend$VpnService` |
| 9 | `local.properties`, `.idea/`, `.kotlin/` committed | Low | Fixed | **Fixed**: All excluded in `.gitignore` |
| 10 | `gradle.properties` pinned single machine JDK path | Low | Fixed | **Fixed**: No `org.gradle.java.home` override |
| 11 | Diagnostics clipboard copy not flagged sensitive | Low | Fixed | **Fixed**: No unredacted secret clipboard export |
| 12 | Scanner sockets proceed when `VpnService.protect()` fails | Low | Unchanged | **Not Applicable**: Clean-IP scanner removed |
| 13 | Raw Mihomo YAML may still set `skip-cert-verify: true` | Low | Unchanged | **Fixed + Tested**: FF Network Connect actively blocks raw YAML containing `skip-cert-verify: true` |
| 14 | `jniStopProxy` closes `server_fd` without synchronization (`byedpi_bridge.cpp`) | Low | Unchanged | **Fixed (Removed)**: ByeByeDPI completely excluded (also satisfies no-DPI-circumvention rule) |
| 15 | Firebase Analytics merges `AD_ID` & referrer permissions | Medium | Unchanged | **Fixed (Removed)**: Zero Firebase/analytics SDKs; manifest contains zero ad-ID permissions |

---

## 3. Authorized Free VPN Providers (Verified 2026 Terms)

| Provider | Official Website | Free Plan | Manual Config Import on Free Tier | Protocols & Limits |
|---|---|---|---|---|
| **Proton VPN Free** | [protonvpn.com/free-vpn](https://protonvpn.com/free-vpn) | Yes | **Yes** — Official WireGuard `.conf` via [account.protonvpn.com](https://protonvpn.com/support/wireguard-configurations) | WireGuard; unlimited data, no ads, audited Swiss no-logs ([Privacy Policy](https://protonvpn.com/privacy-policy)), 1 device limit on Free |
| **Windscribe Free** | [windscribe.com/features/use-for-free](https://windscribe.com/features/use-for-free) | Yes | **No** — Official [Config Generator requires Pro/Build-A-Plan](https://windscribe.com/knowledge-base/articles/how-to-use-windscribe-on-a-router-openvpn-and-wireguard) | 10 GB/mo with email verification via official app only |
| **Cloudflare WARP** | [developers.cloudflare.com/warp-client](https://developers.cloudflare.com/warp-client/) | Yes | **No** — Official 1.1.1.1 client only; no official third-party WireGuard export | Unlimited consumer WARP; anycast edge routing |
| **Custom Authorized Config** | [wireguard.com](https://www.wireguard.com/) | User-owned | **Yes** | Standard WireGuard `.conf` (active out of the box) or Mihomo YAML (when optional native core is built) |

---

## 4. Phone-Only Build Feasibility & Zero-Cost CI Strategy

1. **Exact Technical Limitation on Android Phone (Termux)**:
   - Termux on Android 16 (ARM64) can run `git`, `openjdk-17`, and `golang`, **but** Google's official Android NDK is compiled for `linux-x86_64` hosts and does not ship native ARM64 Android binaries. Compiling `WhiteDNS/FlClash` + `WhiteDNS/mihomo` via CGo + NDK directly on a phone fails without heavy emulation.
2. **Zero-Cost Solution Implemented**:
   - **Prebuilt Official WireGuard JNI**: Using `com.wireguard.android:tunnel:1.0.20230706` from Maven Central supplies real, audited Go/WireGuard native libraries for all Android ABIs with **zero NDK compilation**.
   - **Free GitHub Actions Cloud Build**: Upload `FFNetworkConnect_Android_Source.zip` directly to your GitHub repository root (no unzipping needed on phone) and add `.github/workflows/build-apk.yml`. GitHub Actions (free tier for public repos, 2,000 min/month for private repos) automatically unzips, installs Android SDK 35 via `sdkmanager`, runs `gradle testDebugUnitTest`, builds `app-debug.apk`, and gives you a direct APK download link on your phone!

---

## 5. Bangladesh SIM Operator Compatibility Test Plan

| Network | Test Modes | Metrics Recorded in Room DB |
|---|---|---|
| Grameenphone | Direct + Authorized WireGuard (Proton Free) | Connection setup, DNS ms, TCP RTT, Jitter, Packet Loss %, Stability Score, Handover recovery |
| Robi | Direct + Authorized WireGuard (Proton Free) | Same as above |
| Airtel | Direct + Authorized WireGuard (Proton Free) | Same as above |
| Banglalink | Direct + Authorized WireGuard (Proton Free) | Same as above |
| Teletalk | Direct + Authorized WireGuard (Proton Free) | Same as above |
| Wi-Fi | Direct + Authorized WireGuard (Proton Free) | Same as above |

*Note: No compatibility or ping reduction is claimed prior to on-device testing. A VPN can increase latency depending on routing. General Internet RTT is strictly separated from game-server latency.*

---

## 6. Installation & Maintenance Guide (Android Phone Only)

1. Create a new GitHub repository (e.g., `rjnajmul983/FFNetworkConnect`) in your mobile browser.
2. Upload **`FFNetworkConnect_Android_Source.zip`** directly to the repository root (do not extract on phone).
3. Create **`.github/workflows/build-apk.yml`** using the provided `build-apk.yml` file.
4. Open the **Actions** tab → select **Build FF Network Connect APK** → wait ~3–4 minutes → download **`FFNetworkConnect-Debug-APK`** → install on your Android 16 phone.
5. Open **FF Network Connect**:
   - **Mode B (Diagnostics)** works immediately with zero setup: tap **Measure Now** on Home or **Run Full Diagnostic Test** on Diag.
   - **Mode A (Authorized Free VPN)**: Sign in at [account.protonvpn.com](https://protonvpn.com/support/wireguard-configurations) → Downloads → WireGuard configuration → download `.conf` → open **Servers** tab → tap **Import** → paste `.conf` → tap **Connect** on Home.
