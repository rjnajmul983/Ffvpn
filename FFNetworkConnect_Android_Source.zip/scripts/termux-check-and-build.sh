#!/data/data/com.termux/files/usr/bin/bash
# FF Network Connect — Termux Phone-Only Environment Verification & Helper Script
set -e

echo "=== FF Network Connect: Termux Feasibility Check ==="
pkg update -y && pkg upgrade -y
pkg install -y git curl wget unzip zip nano openjdk-17 golang

echo "Java version:"
java -version
echo "Go version:"
go version
echo "Device Architecture:"
uname -m

echo ""
echo "NOTE ON ANDROID NDK IN TERMUX:"
echo "Google's official Android NDK is distributed for Linux x86_64 hosts, not native ARM64 Android."
echo "Because of this, full native Mihomo/FlClash CGo cross-compilation cannot run natively in Termux without proot/QEMU emulation."
echo "FF Network Connect solves this with ZERO budget by:"
echo "  1) Bundling official WireGuard Android Tunnel (com.wireguard.android:tunnel) prebuilt JNI from Maven Central."
echo "  2) Compiling the complete APK for free via GitHub Actions (.github/workflows/build-apk.yml)."
echo ""
echo "To inspect upstream WhiteVPN locally in Termux:"
echo "  git clone https://github.com/WhiteDNS/WhiteVPN.git"
echo "  cd WhiteVPN && git log -10 --oneline && find . -maxdepth 4 -type f"
